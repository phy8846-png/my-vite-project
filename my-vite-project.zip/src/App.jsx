export default function App() {
  return <h1>Hello Vite + React!</h1>
}
